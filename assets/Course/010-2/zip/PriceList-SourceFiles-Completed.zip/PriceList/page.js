const APIurl = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=USD&order=market_cap_desc&per_page=20&page=1&sparkline=false&locale=en"

$(document).ready(() => {

      console.log(' Page is ready 2')

      FetchData();

      setInterval(() => {
            FetchData();
            console.log('Table Refreshed')
      }, 45000);


})

function FetchData() {
      $.ajax({
            url: APIurl,
            method: 'GET',
            header: {

                  'accept': 'application/json',
                  'x-cg-demo-api-key': 'CG-HzQru23crLnbD2HWqBFhBEmz'

            },
            success: function (result) {
                  //console.info(result)

                  document.getElementById('table-body').innerHTML = ''
                  document.getElementById('loading-frame-id').innerHTML = ''
                  document.getElementById('footer').style.display = 'block'
                  for (let i = 0; i < result.length; i++) {

                        writeARow(result[i])

                  }

            },
            error: function (error) {
                  console.log('An Error happend.')
                  console.log('-------------------------------')
                  console.info(error)
            }
      })
}





function writeARow(input) {
      console.log('Name: ' + input.name)

      var Row = ` <tr>
                              <td>  ${input.market_cap_rank}</td>
                              <td> <img width="36" src="${input.image}" alt="${input.name}">  </td>
                              <td class="coin-name">${input.name}</td>
                              <td>${input.symbol}</td>
                              <td>${input.market_cap}</td>
                              <td>${input.current_price}</td>
                        </tr> `


      document.getElementById('table-body').innerHTML += Row


}